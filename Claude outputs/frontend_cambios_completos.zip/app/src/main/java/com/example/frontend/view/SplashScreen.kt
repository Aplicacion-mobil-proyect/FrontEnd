package com.example.frontend.view

import com.example.frontend.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.frontend.model.Roles
import com.example.frontend.navigation.Rutas
import com.example.frontend.session.Sesion
import com.example.frontend.database.AppDatabase
import com.example.frontend.database.SeedData
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(navController: NavController) {
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        delay(1500)
        // Sin sesión -> Login. Con sesión -> pantalla de inicio según el rol.
        var usuario = Sesion.obtener(context)
        if (usuario != null) {
            // La sesión está en SharedPreferences y los usuarios en Room: si la base se volvió a crear
            // (por ejemplo al subir su versión), el usuario guardado puede ya no existir.
            val db = AppDatabase.getDatabase(context)
            val enBase = try {
                SeedData.cargarSiEstaVacia(db)
                db.usuarioDao().buscarPorId(usuario.id)
            } catch (e: Exception) { null }
            if (enBase == null || enBase.email != usuario.email) {
                Sesion.cerrar(context)          // sesión vieja: se pide iniciar sesión de nuevo
                usuario = null
            } else {
                Sesion.guardar(context, enBase.copy(password = ""))   // refresca nombre, apodo y avatar
                usuario = enBase
            }
        }
        val destino = when {
            usuario == null -> Rutas.LOGIN
            usuario.rol == Roles.ENCARGADO -> Rutas.ENC_MI_RECINTO
            else -> Rutas.HOME
        }
        navController.navigate(destino) { popUpTo(Rutas.SPLASH) { inclusive = true } }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primary) {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Icon(Icons.Filled.AccountBalance, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(72.dp))
            Text(stringResource(R.string.red_patrimonial), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onPrimary)
            Text(stringResource(R.string.de_santiago), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimary)
            Spacer(Modifier.height(32.dp))
            CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary)
        }
    }
}
